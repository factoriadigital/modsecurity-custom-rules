# Nomenclatura de reglas

## IMPORTANTE

Mantener siempre un ID único y secuencial

## Genéricas

Códigos 120xxxx

## Prestashop

Códigos 121xxxx

## WordPress/WooCommerce

Códigos 122xxxx

## Magento

Códigos 123xxxx

## Moodle

Códigos 124xxxx